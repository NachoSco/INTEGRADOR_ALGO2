#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pokemon.h"
#define LONG_MAX_COMAND 10

// Prototipos de funciones
void show_help();
void show_pokemon();
void start_game();

typedef struct {
    char command[LONG_MAX_COMAND];
    void (*funcion_a_ejecutar)();
    char description[100];
} menu_option_t;

typedef struct {
    menu_option_t* options;
    size_t option_count;
} menu_t;

// Función para procesar los comandos del usuario
void process_command(menu_t* menu, const char* command);

// Función para agregar una nueva opción al menú
void add_menu_option(menu_t* menu, const char* command, void (*funcion_a_ejecutar)(), const char* description);

// Función para inicializar el menú
void initialize_menu(menu_t* menu);

// Función para liberar la memoria asignada para el menú
void free_menu(menu_t* menu);

int main() {
    menu_t menu;
    initialize_menu(&menu);

    char command[LONG_MAX_COMAND];

    printf("Bienvenido al juego de carrera de obstáculos Pokemon.\n");
    printf("Escribe 'h' para ver los comandos disponibles.\n");

    while (1) {
        printf("\nIngrese un comando: ");
        if (scanf("%9s", command) == 1) {
            process_command(&menu, command);
        }
    }

    free_menu(&menu);
    return 0;
}

void show_help() {
    printf("Comandos disponibles:\n");
    printf("  h - help: Muestra este mensaje de ayuda.\n");
    printf("  p - pokemon: Muestra los Pokemon disponibles.\n");
    printf("  s - start: Comienza el juego.\n");
}

void show_pokemon() {
    printf("Pokemons disponibles para la carrera:\n");
    printf("  1. Pikachu\n");
    printf("  2. Bulbasaur\n");
    print_bulbasaur();
    printf("  3. Charmander\n");
    print_charmander();
    printf("  4. Squirtle\n");
    print_squirtle();
}

void start_game() {
    printf("Iniciando el juego...\n");
    print_menu();
}

void process_command(menu_t* menu, const char* command) {
    for (size_t i = 0; i < menu->option_count; i++) {
        if (strcmp(menu->options[i].command, command) == 0) {
            menu->options[i].funcion_a_ejecutar();
            return;
        }
    }
    printf("Comando no reconocido. Escriba 'h' para ayuda.\n");
}

void add_menu_option(menu_t* menu, const char* command, void (*funcion_a_ejecutar)(), const char* description) {
    menu->options = realloc(menu->options, sizeof(menu_option_t) * (menu->option_count + 1));
    if (menu->options == NULL) {
        perror("No se pudo agregar la opción del menú");
        exit(EXIT_FAILURE);
    }
    strcpy(menu->options[menu->option_count].command, command);
    menu->options[menu->option_count].funcion_a_ejecutar = funcion_a_ejecutar;
    strncpy(menu->options[menu->option_count].description, description, sizeof(menu->options[menu->option_count].description) - 1);
    menu->option_count++;
}

void initialize_menu(menu_t* menu) {
    menu->options = NULL;
    menu->option_count = 0;
    add_menu_option(menu, "h", show_help, "Muestra este mensaje de ayuda");
    add_menu_option(menu, "p", show_pokemon, "Muestra los Pokemon disponibles");
    add_menu_option(menu, "s", start_game, "Empieza el juego");
}

void free_menu(menu_t* menu) {
    free(menu->options);
    menu->option_count = 0;
}