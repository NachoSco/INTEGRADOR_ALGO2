// pokemon.h

#ifndef POKEMON_H
#define POKEMON_H

#include <stdio.h>

// Color ANSI definitions
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_ORANGE  "\x1b[38;5;214m"
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_RESET   "\x1b[0m"

// Track dimensions
#define PISTA_ANCHO 80
#define PISTA_ALTO 6

// Function declarations
void print_menu();
void print_charmander();
void print_bulbasaur();
void print_squirtle();

#endif // POKEMON_H